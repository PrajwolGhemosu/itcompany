<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class Ourclientsextra extends Model
{
    //
}
