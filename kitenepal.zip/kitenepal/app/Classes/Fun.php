<?php
namespace App\Classes;
use App\ClientGroup;
use App\Ourclients;
use DB;

class Fun{
	public function group($id){
        $Ourclients=DB::table('ourclients')
	        ->join('client_groups','ourclients.group','=','client_groups.id')
	        ->select('client_groups.groups','ourclients.*')->get();
	    return $Ourclients;    
	}
}
?>